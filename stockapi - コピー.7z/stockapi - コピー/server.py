from typing import Any, Dict, List
import httpx
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent
import akshare as ak
import sys
from datetime import datetime, timedelta
import pandas as pd

sys.stdin.reconfigure(encoding='utf-8')
sys.stdout.reconfigure(encoding='utf-8')

# 初始化FastMCP服务器
mcp = FastMCP("stockapi")

# 提供历史行情数据查询的工具
@mcp.tool()
def get_historical_data(symbol) -> Dict[str, Any]:
    """
    获取指定股票的历史行情数据
    :param symbol: 股票代码 (例如: "600000" 或 "000001")
    :return: 历史行情数据
    """
    try:
        # 获取今天的日期
        end_date = datetime.today()        
        # 计算 500 天前的日期
        start_date = end_date - timedelta(days=500)
        start_date = start_date.strftime('%Y%m%d')
        end_date = end_date.strftime('%Y%m%d')
        # print(start_date, end_date)

        # 使用 akshare 获取历史行情数据
        stock_zh_a_hist_df = ak.stock_zh_a_hist(symbol=str(symbol), period="daily", start_date=start_date, end_date=end_date, adjust="qfq")
        # print(stock_zh_a_hist_df)
        # 将 DataFrame 转换为字典格式
        historical_data = stock_zh_a_hist_df.tail(500).to_dict(orient="records")
        
        # 返回历史行情数据
        return {
            "content": [TextContent(type="text", text=str(historical_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 1. 沪深京 A 股-每日分时行情
@mcp.tool()
def get_stock_min_data(symbol, period="1") -> Dict[str, Any]:
    """
    获取指定股票的分时行情数据
    :param symbol: 股票代码 (例如: "600000" 或 "000001")
    :param period: 分时周期，可选 1, 5, 15, 30, 60 分钟
    :return: 分时行情数据
    """
    try:
        # 使用 akshare 获取分时行情数据
        stock_min_df = ak.stock_zh_a_hist_min_em(symbol=str(symbol), period=period)
        # 将 DataFrame 转换为字典格式
        min_data = stock_min_df.tail(300).tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(min_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 2. 沪深京 A 股-实时行情
@mcp.tool()
def get_stock_spot_data() -> Dict[str, Any]:
    """
    获取沪深京 A 股实时行情数据
    :return: 实时行情数据
    """
    try:
        # 使用 akshare 获取实时行情数据
        stock_spot_df = ak.stock_zh_a_spot_em()
        # 将 DataFrame 转换为字典格式
        spot_data = stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 3. 新股-实时行情
@mcp.tool()
def get_new_stock_spot_data() -> Dict[str, Any]:
    """
    获取新股实时行情数据
    :return: 新股实时行情数据
    """
    try:
        # 使用 akshare 获取新股实时行情数据
        new_stock_spot_df = ak.stock_new_a_spot_em()
        # 将 DataFrame 转换为字典格式
        new_spot_data = new_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(new_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 4. 创业板-实时行情
@mcp.tool()
def get_cy_stock_spot_data() -> Dict[str, Any]:
    """
    获取创业板实时行情数据
    :return: 创业板实时行情数据
    """
    try:
        # 使用 akshare 获取创业板实时行情数据
        cy_stock_spot_df = ak.stock_cy_a_spot_em()
        # 将 DataFrame 转换为字典格式
        cy_spot_data = cy_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(cy_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 5. 科创板-实时行情
@mcp.tool()
def get_kc_stock_spot_data() -> Dict[str, Any]:
    """
    获取科创板实时行情数据
    :return: 科创板实时行情数据
    """
    try:
        # 使用 akshare 获取科创板实时行情数据
        kc_stock_spot_df = ak.stock_kc_a_spot_em()
        # 将 DataFrame 转换为字典格式
        kc_spot_data = kc_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(kc_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 6. B 股-实时行情
@mcp.tool()
def get_b_stock_spot_data() -> Dict[str, Any]:
    """
    获取B股实时行情数据
    :return: B股实时行情数据
    """
    try:
        # 使用 akshare 获取B股实时行情数据
        b_stock_spot_df = ak.stock_zh_b_spot_em()
        # 将 DataFrame 转换为字典格式
        b_spot_data = b_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(b_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 7. 港股-实时行情
@mcp.tool()
def get_hk_stock_spot_data() -> Dict[str, Any]:
    """
    获取港股实时行情数据
    :return: 港股实时行情数据
    """
    try:
        # 使用 akshare 获取港股实时行情数据
        hk_stock_spot_df = ak.stock_hk_spot_em()
        # 将 DataFrame 转换为字典格式
        hk_spot_data = hk_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hk_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 8. 港股-每日行情
@mcp.tool()
def get_hk_stock_hist_data(symbol) -> Dict[str, Any]:
    """
    获取港股每日行情数据
    :param symbol: 港股股票代码（例如: "00700"）
    :return: 港股每日行情数据
    """
    try:
        # 使用 akshare 获取港股历史行情数据
        hk_stock_hist_df = ak.stock_hk_hist(symbol=str(symbol))
        # 将 DataFrame 转换为字典格式
        hk_hist_data = hk_stock_hist_df.tail(300).tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hk_hist_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 9. 港股-每日分时行情
@mcp.tool()
def get_hk_stock_min_data(symbol, period="1") -> Dict[str, Any]:
    """
    获取指定港股的分时行情数据
    :param symbol: 港股股票代码（例如: "00700"）
    :param period: 分时周期，可选 1, 5, 15, 30, 60 分钟
    :return: 分时行情数据
    """
    try:
        # 使用 akshare 获取港股分时行情数据
        hk_stock_min_df = ak.stock_hk_hist_min_em(symbol=str(symbol), period=period)
        # 将 DataFrame 转换为字典格式
        hk_min_data = hk_stock_min_df.tail(300).tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hk_min_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 10. 美股-实时行情
@mcp.tool()
def get_us_stock_spot_data() -> Dict[str, Any]:
    """
    获取美股实时行情数据
    :return: 美股实时行情数据
    """
    try:
        # 使用 akshare 获取美股实时行情数据
        us_stock_spot_df = ak.stock_us_spot_em()
        # 将 DataFrame 转换为字典格式
        us_spot_data = us_stock_spot_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(us_spot_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 11. 美股-每日行情
@mcp.tool()
def get_us_stock_hist_data(symbol) -> Dict[str, Any]:
    """
    获取美股每日行情数据
    :param symbol: 美股股票代码（例如: "AAPL"）
    :return: 美股每日行情数据
    """
    try:
        # 使用 akshare 获取美股历史行情数据
        us_stock_hist_df = ak.stock_us_hist(symbol=str(symbol), period="daily")
        # 将 DataFrame 转换为字典格式
        us_hist_data = us_stock_hist_df.tail(300).tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(us_hist_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 12. 雪球-沪深股市-热度排行榜-关注排行榜
@mcp.tool()
def get_xq_hot_follow_data() -> Dict[str, Any]:
    """
    获取雪球沪深股市关注排行榜数据
    :return: 雪球关注度排行榜数据
    """
    try:
        # 使用 akshare 获取雪球关注排行榜数据
        xq_hot_follow_df = ak.stock_hot_follow_xq()
        # 将 DataFrame 转换为字典格式
        xq_follow_data = xq_hot_follow_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(xq_follow_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 13. 雪球-沪深股市-热度排行榜-讨论排行榜
@mcp.tool()
def get_xq_hot_tweet_data() -> Dict[str, Any]:
    """
    获取雪球沪深股市讨论排行榜数据
    :return: 雪球讨论度排行榜数据
    """
    try:
        # 使用 akshare 获取雪球讨论排行榜数据
        xq_hot_tweet_df = ak.stock_hot_tweet_xq()
        # 将 DataFrame 转换为字典格式
        xq_tweet_data = xq_hot_tweet_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(xq_tweet_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 14. 雪球-沪深股市-热度排行榜-分享交易排行榜
@mcp.tool()
def get_xq_hot_deal_data() -> Dict[str, Any]:
    """
    获取雪球沪深股市分享交易排行榜数据
    :return: 雪球分享交易排行榜数据
    """
    try:
        # 使用 akshare 获取雪球分享交易排行榜数据
        xq_hot_deal_df = ak.stock_hot_deal_xq()
        # 将 DataFrame 转换为字典格式
        xq_deal_data = xq_hot_deal_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(xq_deal_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 15. 东方财富网-数据中心-资金流向-沪深港通资金流向
@mcp.tool()
def get_hsgt_fund_flow_data() -> Dict[str, Any]:
    """
    获取沪深港通资金流向汇总数据
    :return: 沪深港通资金流向汇总数据
    """
    try:
        # 使用 akshare 获取沪深港通资金流向数据
        hsgt_fund_flow_df = ak.stock_hsgt_fund_flow_summary_em()
        # 将 DataFrame 转换为字典格式
        hsgt_flow_data = hsgt_fund_flow_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hsgt_flow_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 16. 东方财富网-行情中心-港股市场-港股通成份股
@mcp.tool()
def get_hk_ggt_components_data() -> Dict[str, Any]:
    """
    获取港股通成份股数据
    :return: 港股通成份股数据
    """
    try:
        # 使用 akshare 获取港股通成份股数据
        hk_ggt_components_df = ak.stock_hk_ggt_components_em()
        # 将 DataFrame 转换为字典格式
        hk_components_data = hk_ggt_components_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hk_components_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 17. 东方财富-数据中心-沪深港通持股-个股排行
@mcp.tool()
def get_hsgt_hold_stock_data(market="北向", indicator="今日排行") -> Dict[str, Any]:
    """
    获取沪深港通持股个股排行数据
    :param market: 市场，可选 "北向", "沪股通", "深股通", "南向", "港股通(沪)", "港股通(深)"
    :param indicator: 指标，可选 "今日排行", "3日排行", "5日排行", "10日排行", "月排行", "季排行", "年排行"
    :return: 沪深港通持股个股排行数据
    """
    try:
        # 使用 akshare 获取沪深港通持股个股排行数据
        hsgt_hold_stock_df = ak.stock_hsgt_hold_stock_em(market=market, indicator=indicator)
        # 将 DataFrame 转换为字典格式
        hsgt_hold_data = hsgt_hold_stock_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(hsgt_hold_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 18. 新浪财经-交易日历-历史数据
@mcp.tool()
def get_trade_date_hist_sina() -> Dict[str, Any]:
    """
    获取新浪财经交易日历历史数据
    :return: 交易日历历史数据
    """
    try:
        # 使用 akshare 获取交易日历历史数据
        trade_date_hist_df = ak.tool_trade_date_hist_sina()
        # 将 DataFrame 转换为字典格式
        trade_date_data = trade_date_hist_df.tail(500).to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(trade_date_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

# 19. 巨潮资讯-个股-历史分红
@mcp.tool()
def get_stock_dividend_cninfo(symbol) -> Dict[str, Any]:
    """
    获取巨潮资讯个股历史分红数据
    :param symbol: 股票代码 (例如: "600009")
    :return: 历史分红数据
    """
    try:
        # 使用 akshare 获取个股历史分红数据
        stock_dividend_df = ak.stock_dividend_cninfo(symbol=str(symbol))
        # 将 DataFrame 转换为字典格式
        dividend_data = stock_dividend_df.to_dict(orient="records")
        
        return {
            "content": [TextContent(type="text", text=str(dividend_data))]
        }
    except Exception as e:
        return {
            "isError": True,
            "content": [TextContent(type="text", text=f"Error: {str(e)}")]
        }

if __name__ == "__main__":
    # 初始化并运行服务器
    mcp.run(transport='stdio')

# df = get_historical_data("600000")
# print(df)